import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart' as p;

void main() => runApp(const LinkPilotApp());

class LinkPilotApp extends StatelessWidget {
  const LinkPilotApp({super.key});
  @override
  Widget build(BuildContext context) {
    const navy = Color(0xFF101828);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'LinkPilot AI',
      theme: ThemeData(useMaterial3: true, scaffoldBackgroundColor: const Color(0xFFF5F7FB),
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF2563EB)),
        fontFamily: 'Roboto'),
      home: const DashboardPage(),
    );
  }
}

class LocalHistory {
  static Database? _db;
  static Future<Database> get db async {
    if (_db != null) return _db!;
    final path = p.join(await getDatabasesPath(), 'linkpilot_history.db');
    _db = await openDatabase(path, version: 1, onCreate: (db, v) async {
      await db.execute('''CREATE TABLE posts(
        id TEXT PRIMARY KEY, body TEXT NOT NULL, status TEXT NOT NULL,
        created_at TEXT NOT NULL, cloud_synced INTEGER NOT NULL DEFAULT 0)''');
    });
    return _db!;
  }
  static Future<void> addDraft(String body) async {
    final d = await db;
    await d.insert('posts', {'id': DateTime.now().microsecondsSinceEpoch.toString(),
      'body': body, 'status': 'Draft', 'created_at': DateTime.now().toIso8601String()});
  }
}

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});
  @override State<DashboardPage> createState() => _DashboardPageState();
}
class _DashboardPageState extends State<DashboardPage> {
  int tab = 0;
  bool autoPublish = false;
  bool connected = false;
  final draft = TextEditingController();
  final posts = <Map<String,String>>[
    {'title':'The importance of detection engineering','status':'Awaiting approval','date':'Today · 8:00 PM'},
    {'title':'API security: beyond authentication','status':'Published','date':'Yesterday · 8:00 PM'},
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(backgroundColor: const Color(0xFFF5F7FB), title: const Row(children:[
        Icon(Icons.bolt_rounded, color: Color(0xFF2563EB)), SizedBox(width:8),
        Text('LinkPilot AI', style: TextStyle(fontWeight: FontWeight.w800))]),
        actions:[IconButton(onPressed:(){}, icon:const Icon(Icons.notifications_none)), const SizedBox(width:8)]),
      body: IndexedStack(index:tab, children:[_home(), _history(), _settings()]),
      bottomNavigationBar: NavigationBar(selectedIndex:tab, onDestinationSelected:(v)=>setState(()=>tab=v),
        destinations: const [
          NavigationDestination(icon:Icon(Icons.dashboard_outlined),selectedIcon:Icon(Icons.dashboard),label:'Home'),
          NavigationDestination(icon:Icon(Icons.history),label:'History'),
          NavigationDestination(icon:Icon(Icons.tune),label:'Settings')]),
      floatingActionButton: tab==0 ? FloatingActionButton.extended(onPressed:_newDraft,
        icon:const Icon(Icons.edit), label:const Text('New post')) : null,
    );
  }
  Widget _home() => ListView(padding:const EdgeInsets.fromLTRB(18,8,18,100), children:[
    Container(padding:const EdgeInsets.all(20), decoration:BoxDecoration(
      gradient:const LinearGradient(colors:[Color(0xFF172B4D),Color(0xFF2563EB)]),
      borderRadius:BorderRadius.circular(24)), child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        const Text('YOUR LINKEDIN WORKSPACE',style:TextStyle(color:Colors.white70,fontSize:11,letterSpacing:1.2)),
        const SizedBox(height:12), const Text('Build your presence\nwith AI.',style:TextStyle(color:Colors.white,fontSize:27,fontWeight:FontWeight.w800)),
        const SizedBox(height:18), Row(children:[
          const Icon(Icons.schedule,color:Colors.white70,size:17), const SizedBox(width:7),
          const Text('Daily schedule · 8:00 PM (Dhaka)',style:TextStyle(color:Colors.white))]) ])),
    const SizedBox(height:18),
    Row(children:[Expanded(child:_stat('Published','12',Icons.send_rounded)),const SizedBox(width:12),Expanded(child:_stat('Pending','3',Icons.hourglass_top_rounded))]),
    const SizedBox(height:22),
    _section('Account connection', trailing: connected ? 'Connected' : 'Not connected'),
    Card(child:ListTile(leading:const CircleAvatar(backgroundColor:Color(0xFFE8F0FE),child:Icon(Icons.business_center,color:Color(0xFF0A66C2))),
      title:Text(connected?'LinkedIn account connected':'Connect your LinkedIn'),
      subtitle:const Text('One personal profile · Official authorization'),
      trailing:FilledButton(onPressed:()=>setState(()=>connected=!connected),child:Text(connected?'Manage':'Connect')))),
    const SizedBox(height:18), _section('Publishing mode',trailing:'Mixed'),
    Card(child:SwitchListTile(value:autoPublish,onChanged:(v)=>setState(()=>autoPublish=v),
      title:const Text('Allow automatic publishing',style:TextStyle(fontWeight:FontWeight.w700)),
      subtitle:Text(autoPublish?'Approved schedule can publish automatically':'New AI posts wait for your approval'),
      secondary:const Icon(Icons.auto_awesome))),
    const SizedBox(height:18), _section('Upcoming content',trailing:'View all'),
    ...posts.map((x)=>Card(child:ListTile(leading:const Icon(Icons.article_outlined),
      title:Text(x['title']!),subtitle:Text(x['date']!),trailing:Container(padding:const EdgeInsets.symmetric(horizontal:9,vertical:6),
      decoration:BoxDecoration(color:x['status']=='Published'?const Color(0xFFE6F7EF):const Color(0xFFFFF4DB),borderRadius:BorderRadius.circular(20)),
      child:Text(x['status']!,style:const TextStyle(fontSize:10,fontWeight:FontWeight.w700)))))),
  ]);
  Widget _stat(String label,String value,IconData icon)=>Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
    Icon(icon,color:const Color(0xFF2563EB)),const SizedBox(height:12),Text(value,style:const TextStyle(fontSize:25,fontWeight:FontWeight.w800)),
    Text(label,style:const TextStyle(color:Colors.black54))])));
  Widget _section(String title,{String? trailing})=>Padding(padding:const EdgeInsets.only(bottom:8),child:Row(children:[
    Expanded(child:Text(title,style:const TextStyle(fontWeight:FontWeight.w800,fontSize:16))),
    if(trailing!=null) Text(trailing,style:const TextStyle(color:Color(0xFF2563EB),fontWeight:FontWeight.w600))]));
  Widget _history()=>ListView(padding:const EdgeInsets.all(18),children:[
    const Text('Post history',style:TextStyle(fontSize:25,fontWeight:FontWeight.w800)),
    const SizedBox(height:6),const Text('Your published posts and approval queue.'),
    const SizedBox(height:18),...posts.map((x)=>Card(child:ListTile(leading:const Icon(Icons.article),
      title:Text(x['title']!),subtitle:Text(x['date']!),trailing:Text(x['status']!,style:const TextStyle(fontSize:11,color:Color(0xFF2563EB))))))]);
  Widget _settings()=>ListView(padding:const EdgeInsets.all(18),children:[
    const Text('Settings',style:TextStyle(fontSize:25,fontWeight:FontWeight.w800)),
    const SizedBox(height:18),const Card(child:ListTile(leading:Icon(Icons.verified_user),title:Text('License status'),subtitle:Text('Demo mode · Activation API required'))),
    const Card(child:ListTile(leading:Icon(Icons.cloud_sync),title:Text('Cloud backup'),subtitle:Text('Local history + cloud sync scaffold'))),
    const Card(child:ListTile(leading:Icon(Icons.schedule),title:Text('Daily publishing time'),subtitle:Text('8:00 PM · Asia/Dhaka'))),
    const Card(child:ListTile(leading:Icon(Icons.security),title:Text('Privacy & security'),subtitle:Text('LinkedIn password is never collected'))),
  ]);
  void _newDraft()=>showModalBottomSheet(context:context,isScrollControlled:true,builder:(ctx)=>Padding(
    padding:EdgeInsets.fromLTRB(20,20,20,MediaQuery.of(ctx).viewInsets.bottom+20),
    child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[
      const Text('Create a post',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
      const SizedBox(height:12),TextField(controller:draft,maxLines:5,decoration:const InputDecoration(hintText:'Write or generate a cybersecurity post...',border:OutlineInputBorder())),
      const SizedBox(height:12),SizedBox(width:double.infinity,child:FilledButton(onPressed:()async{
        if(draft.text.trim().isNotEmpty){await LocalHistory.addDraft(draft.text.trim()); if(ctx.mounted)Navigator.pop(ctx); draft.clear();}
      },child:const Text('Save draft locally'))),
    ])));
}
