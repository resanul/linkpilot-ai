# LinkedIn AI Automation — MVP Starter

A Flutter Android app + FastAPI backend starter for a license-gated, single-LinkedIn-account automation product.

## Included
- Flutter dashboard UI with mixed publishing mode (approval queue + auto-publish setting)
- Local SQLite post history model
- FastAPI backend skeleton for license activation, Google ID-token verification hook, LinkedIn OAuth start/callback placeholders, post drafts/history sync
- Scheduler scaffold (Asia/Dhaka, 20:00) with a safe no-op publisher until LinkedIn OAuth/API is configured
- `.env.example`, Dockerfile and API notes

## Important status
This is a **starter implementation**, not a production-connected app. LinkedIn OAuth credentials, Google OAuth audience, database, HTTPS deployment, AI provider key, and LinkedIn API product approval/configuration are not supplied. The LinkedIn publish adapter deliberately fails closed until configured. Do not add real tokens to source control.

## Architecture
- Android app: Flutter
- API: FastAPI
- Cloud DB: PostgreSQL (SQLAlchemy)
- Local history: SQLite (`sqflite`)
- Scheduler: APScheduler
- AI: provider adapter placeholder; configure an API provider server-side
- LinkedIn: official OAuth 2.0 member authorization and Posts API only

## Run backend locally
```bash
cd backend
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload
```
The API health endpoint is `GET /health`.

## Issue a license (admin-side, local/dev only)
```bash
cd backend
python scripts/create_license.py YOUR-ONE-TIME-LICENSE-KEY
```
This stores only a SHA-256 hash. For production, replace this with an authenticated admin console, stronger keyed hashing, expiry/plan/device limits, audit logs and payment-provider webhook verification.

## Run Flutter app
Install Flutter and Android Studio, then:
```bash
cd mobile
flutter create .
flutter pub get
flutter run
```
The current mobile app is a UI + local-history scaffold. Configure `API_BASE_URL` and Google Sign-In/OAuth before connecting real accounts.

## Required setup before live publishing
1. Create Google OAuth credentials and set `GOOGLE_CLIENT_ID` (backend must verify ID tokens; do not trust a client-supplied email).
2. Configure LinkedIn app OAuth redirect URI to `https://YOUR_API_HOST/linkedin/callback`.
3. Request/enable LinkedIn "Share on LinkedIn" and use the minimum required permission (`w_member_social`). LinkedIn access and API behavior are controlled by LinkedIn.
4. Add `LINKEDIN_CLIENT_ID`, `LINKEDIN_CLIENT_SECRET`, `LINKEDIN_REDIRECT_URI`, and a supported API version to a secret manager.
5. Implement token encryption with a managed KMS/secret manager before storing refresh/access tokens.
6. Set `DATABASE_URL`, `AI_PROVIDER`, and `AI_API_KEY` in server environment.
7. Deploy backend and worker with HTTPS; configure backups, rate limits, audit logging and tenant isolation.
8. Test with a developer/test account before enabling automatic publishing.

## Mixed publishing behavior
- `approval_required=true`: generated post remains pending until user approves.
- `approval_required=false`: generated post is eligible for scheduled publishing.
- A user-level setting controls the default; each post can override it.
- Never auto-comment on arbitrary feed posts. Comment workflows must be user-selected and permitted by the LinkedIn API product/scopes.

## Privacy and security
- Google login is for app identity; LinkedIn OAuth separately authorizes publishing.
- Never collect LinkedIn passwords.
- Keep client secrets and provider keys on the backend only.
- Encrypt OAuth tokens at rest; use HTTPS; enforce ownership checks on every record.
- Local SQLite is a convenience copy, not the only backup. Cloud history remains the source of truth.
