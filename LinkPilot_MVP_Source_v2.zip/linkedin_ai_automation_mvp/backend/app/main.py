from contextlib import asynccontextmanager
from uuid import uuid4
from fastapi import FastAPI, Depends, HTTPException
from sqlalchemy.orm import Session
from .db import Base, engine, get_db
from .models import User, License, Post
from .schemas import LicenseActivate, PostCreate, PostOut
from .security import verify_google_id_token, hash_license_key
from .linkedin import authorization_url
from .scheduler import start_scheduler

@asynccontextmanager
async def lifespan(app: FastAPI):
    Base.metadata.create_all(bind=engine)
    start_scheduler()
    yield

app = FastAPI(title="LinkedIn AI Automation API", version="0.1.0", lifespan=lifespan)

@app.get("/health")
def health():
    return {"status": "ok", "service": "linkedin-ai-automation"}

def current_user(claims=Depends(verify_google_id_token), db: Session=Depends(get_db)):
    sub = claims.get("sub")
    if not sub:
        raise HTTPException(401, "Google subject missing")
    user = db.query(User).filter_by(google_sub=sub).first()
    if not user:
        user = User(id=str(uuid4()), google_sub=sub, email=claims.get("email", ""))
        db.add(user); db.commit(); db.refresh(user)
    return user

@app.post("/license/activate")
def activate_license(payload: LicenseActivate, user=Depends(current_user), db: Session=Depends(get_db)):
    item = db.query(License).filter_by(key_hash=hash_license_key(payload.license_key), active=True).first()
    if not item:
        raise HTTPException(403, "Invalid or inactive license")
    if item.user_id and item.user_id != user.id:
        raise HTTPException(409, "License already assigned")
    item.user_id = user.id
    db.commit()
    return {"active": True, "license_id": item.id}

@app.get("/linkedin/connect")
def linkedin_connect(user=Depends(current_user)):
    url, state = authorization_url()
    # Production: persist state bound to user, expire it quickly, use PKCE where supported.
    return {"authorization_url": url, "state": state}

@app.get("/posts", response_model=list[PostOut])
def list_posts(user=Depends(current_user), db: Session=Depends(get_db)):
    return db.query(Post).filter_by(user_id=user.id).order_by(Post.created_at.desc()).limit(100).all()

@app.post("/posts", response_model=PostOut)
def create_post(payload: PostCreate, user=Depends(current_user), db: Session=Depends(get_db)):
    post = Post(id=str(uuid4()), user_id=user.id, body=payload.body,
                status="pending_approval" if payload.approval_required else "scheduled",
                approval_required=payload.approval_required, scheduled_at=payload.scheduled_at)
    db.add(post); db.commit(); db.refresh(post)
    return post

@app.post("/posts/{post_id}/approve")
def approve_post(post_id: str, user=Depends(current_user), db: Session=Depends(get_db)):
    post = db.query(Post).filter_by(id=post_id, user_id=user.id).first()
    if not post: raise HTTPException(404, "Post not found")
    if post.status != "pending_approval": raise HTTPException(409, "Post is not awaiting approval")
    post.status = "scheduled"
    db.commit()
    return {"id": post.id, "status": post.status}
