import hashlib
from google.oauth2 import id_token
from google.auth.transport import requests
from fastapi import HTTPException, Header
from .config import settings

def verify_google_id_token(authorization: str | None = Header(default=None)):
    # Send: Authorization: Bearer <Google ID token>.
    # Verify signature, issuer, audience and expiry server-side.
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(401, "Missing Google ID token")
    token = authorization.split(" ", 1)[1]
    if not settings.google_client_id:
        raise HTTPException(503, "Google OAuth is not configured")
    try:
        return id_token.verify_oauth2_token(token, requests.Request(), settings.google_client_id)
    except Exception:
        raise HTTPException(401, "Invalid Google ID token")

def hash_license_key(value: str) -> str:
    return hashlib.sha256(value.strip().encode()).hexdigest()
