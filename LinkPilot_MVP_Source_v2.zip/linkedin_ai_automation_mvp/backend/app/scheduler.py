from apscheduler.schedulers.asyncio import AsyncIOScheduler
from zoneinfo import ZoneInfo

scheduler = AsyncIOScheduler(timezone=ZoneInfo("Asia/Dhaka"))

async def scheduled_publish_worker():
    # TODO: query due posts with status='scheduled', acquire row-level lock,
    # verify active license + valid LinkedIn consent, publish, then persist result.
    # Keep this no-op until token encryption and tenant checks are implemented.
    return

def start_scheduler():
    scheduler.add_job(scheduled_publish_worker, "cron", hour=20, minute=0,
                      id="daily-publish", replace_existing=True, max_instances=1)
    scheduler.start()
