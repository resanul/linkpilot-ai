from fastapi import HTTPException
from .config import settings

async def generate_cybersecurity_post(topic: str = "cybersecurity") -> str:
    # Provider integration intentionally left as a server-side adapter.
    # Never expose the API key to the mobile app. Add moderation, fact checks,
    # duplicate detection and source validation before enabling auto-publish.
    if not settings.ai_api_key:
        raise HTTPException(503, "AI provider is not configured")
    raise HTTPException(501, "Configure the selected AI provider adapter before generation")
