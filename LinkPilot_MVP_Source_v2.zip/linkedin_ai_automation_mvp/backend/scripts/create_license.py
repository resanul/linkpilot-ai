import sys
from uuid import uuid4
from app.db import Base, engine, SessionLocal
from app.models import License
from app.security import hash_license_key

if len(sys.argv) != 2:
    raise SystemExit("Usage: python scripts/create_license.py LICENSE-KEY")
key = sys.argv[1].strip()
Base.metadata.create_all(bind=engine)
db = SessionLocal()
try:
    item = License(id=str(uuid4()), key_hash=hash_license_key(key), active=True, user_id=None)
    db.add(item)
    db.commit()
    print(f"Created license record: {item.id}")
    print("Store the plaintext key securely and deliver it to the purchaser once.")
finally:
    db.close()
